#Write your code below this line 👇
print('Day 1 - Python Print Function\nThe function is declared like this:')
print("print('what to print')")









